//
//  Endpoints.swift
//  FindGitRepo
//  Default URls
//  Created by Shashank Mishra on 26/05/18.
//  Copyright © 2018 Shashank Mishra. All rights reserved.
//

import Foundation

class Endpoints {
    
    static let endPointShared = Endpoints()
    
    let apiBaseURI = "https://api.github.com/"
    
    //Get Public repositories
    var getPublicRepos: String {
        get {
            return apiBaseURI + "search/repositories"
        }
    }
    
    //Search repository Issues
    var getRepoIssues: String {
        get {
            return apiBaseURI + "search/issues"
        }
    }
    
    //Get Contributors
    var getContributorsRepos: String {
        get {
            return apiBaseURI + "repos"
        }
    }
    
}
