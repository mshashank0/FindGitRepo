//
//  GitRepoAPIs.swift
//  FindGitRepo
//  APIs for GitHub Repo
//  Created by Shashank Mishra on 26/05/18.
//  Copyright © 2018 Shashank Mishra. All rights reserved.
//

import Alamofire

class GitRepoAPIs: Endpoints {
    
    static let shared = GitRepoAPIs()
    
    func getRepoFor(language: String, completion: @escaping ([RepoDetails]?) -> Void) {
        
        //Added additional parameters to get popular & sorted repositories in descending order
        let url = "\(getPublicRepos)?q=\(language)+language:\(language)+sort=stars&order=desc"
        
        Alamofire.request(url, method: .get, parameters: nil, encoding: JSONEncoding.default, headers: ["Accept": "application/vnd.github.mercy-preview+json"])
            
            .responseJSON { (response) in
                
                switch response.result
                {
                case .success(_):
                    if let json = response.result.value as? [String: Any],let itemsArray = json["items"] as? [[String: Any]], itemsArray.count > 0 {
                        var repoDetailsArray: [RepoDetails] = []
                        for item in itemsArray {
                            guard let repoDetails = RepositoryData.getRepoDetails(item) else {
                                continue
                            }
                            repoDetailsArray.append(repoDetails)
                        }
                        completion(repoDetailsArray)
                    }
                    else {
                        completion(nil)
                    }
                case .failure(_):
                    completion(nil)
                }
                
        }
    }
    
    func getIssuesFor(repoName: String, completion: @escaping (RepoIssues?) -> Void) {
        
        //Added additional parameters to get recent & sorted issues in descending order
        let url = "\(getRepoIssues)?q=repo:\(repoName)+sort=created&order=desc"
        
        Alamofire.request(url, method: .get, parameters: nil, encoding: JSONEncoding.default, headers: ["Accept": "application/vnd.github.v3.text-match+json"])
            
            .responseJSON { (response) in
                
                switch response.result
                {
                case .success(_):
                    if let json = response.result.value as? [String: Any], let itemsArray = json["items"] as? [[String: Any]], itemsArray.count > 0 {
                        
                        guard let repoIssuesArray = RepositoryData.getRepoIssues(itemsArray) else {
                            completion(nil)
                            return
                        }
                        completion(repoIssuesArray)
                    }
                    else {
                        completion(nil)
                    }
                case .failure(_):
                    completion(nil)
                }
                
        }
    }
    
    func getContributorsFor(repoName: String, ownerName: String, completion: @escaping (RepoContributors?) -> Void) {
        
        //It provides list in sorted order based on contributions count by default.
        let url = "\(getContributorsRepos)/\(ownerName)/\(repoName)/contributors"
        
        Alamofire.request(url, method: .get, parameters: nil, encoding: JSONEncoding.default, headers: ["Accept": "application/vnd.github.v3.text-match+json"])
            
            .responseJSON { (response) in
                
                switch response.result
                {
                case .success(_):
                    if let jsonArray = response.result.value as? [[String: Any]], jsonArray.count > 0 {
                        
                        guard let repoContriArray = RepositoryData.getRepoContributors(jsonArray) else {
                            completion(nil)
                            return
                        }
                        completion(repoContriArray)
                    }
                    else {
                        completion(nil)
                    }
                case .failure(_):
                    completion(nil)
                }
                
        }
    }
    
}
