//
//  FindGitRepoTests.swift
//  FindGitRepoTests
//
//  Created by Shashank Mishra on 25/05/18.
//  Copyright © 2018 Shashank Mishra. All rights reserved.
//

import XCTest
@testable import FindGitRepo

class FindGitRepoTests: XCTestCase {
    
    override func setUp() {
        super.setUp()
        // Put setup code here. This method is called before the invocation of each test method in the class.
    }
    
    override func tearDown() {
        // Put teardown code here. This method is called after the invocation of each test method in the class.
        super.tearDown()
    }
    
    func testBasic() {
        // This is an example of a functional test case.
        GitRepoAPIs.shared.getRepoFor(language: "Java") { (reponseArray) in
            print((reponseArray != nil) ? "Repo available": "Repo not available")
        }
        
        GitRepoAPIs.shared.getIssuesFor(repoName: "AndreaOm/awesome-stars") { (repoIssuesArray) in
           print((repoIssuesArray != nil) ? "Issues available": "Issues not available")
        }
        
        GitRepoAPIs.shared.getContributorsFor(repoName: "awesome-stars", ownerName: "AndreaOm") { (repoContriArray) in
            print((repoContriArray != nil) ? "Contributors available": "Contributors not available")
        }
    }
    
    func testPerformanceExample() {
        // This is an example of a performance test case.
        self.measure {
            // Put the code you want to measure the time of here.
        }
    }
    
}
